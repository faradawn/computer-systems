from __future__ import annotations
from locale import currency
from select import select

import numpy as np

import random


def compute_return(portfolio_values: np.ndarray) -> float:
    """Computes total return given portfolio values over time.

    Parameters
    ----------
    portfolio_values : np.ndarray[float]
        Time series of portfolio values.

    Returns
    -------
    return_percentage : float
        Total return, in percentage points.

    Example
    -------
    >>> values = np.array([50, 48, 51, 55, 57, 60, 58, 54, 56, 57])
    14.0
    """
    return ((portfolio_values[-1]-portfolio_values[0])/portfolio_values[0])*100


def compute_max_drawdown(portfolio_values: np.ndarray) -> float:
    """Computes maximum drawdown given portfolio values over time.

    Parameters
    ----------
    portfolio_values : np.ndarray[float]
        Time series of portfolio values.

    Returns
    -------
    max_drawdown : float
        Maximum drawdown, in percentage points.

    Example
    -------
    >>> values = np.array([50, 48, 51, 55, 57, 60, 58, 54, 56, 57])
    10.0
    """
    
    peak = portfolio_values[0]
    max_draw_down = 0.0
    i = 0
    while True:
        min = portfolio_values[i]
        j = i + 1
        while j < len(portfolio_values) and portfolio_values[j] <= peak:
            if portfolio_values[j] < min:
                min = portfolio_values[j]
            j += 1

        local_draw_down = (peak - min)/peak
        if local_draw_down > max_draw_down:
            max_draw_down = local_draw_down

        if j == len(portfolio_values):
            break
        else:
            peak = portfolio_values[j]
            i = j

    return max_draw_down*100




def optimize_portfolio(asset_values: np.ndarray) -> tuple[list[int], float]:
    """Uses local search to choose a subset of the assets which maximizes return/risk.
    Neighborhood: every step, consider adding one asset or removing an existing asset.
    First consider adding: we pick the first asset could increase our return/risk ratio. 
    Then consider removing: we loop through the current selections and remove the first asset 
    removing which could increase our return/risk ratio. 
    At every step, at most one addition and one removal. 
    Terminate when no update can be performed.
    

    Parameters
    ----------
    asset_values : np.ndarray[float]
        2D array where row i contains a time series of values for the ith asset.

    Returns
    -------
    portfolio_assets : list[int]
        Sorted list of indices corresponding to the assets included in the portfolio.
    return_over_risk : float
        Return divided by maximum drawdown (objective function value) for the chosen assets.

    Example
    -------
    >>> values = [[100, 99, 98, 101, 102], [100, 95, 88, 96, 103], [100, 103, 107, 106, 104]]
    >>> optimize_portfolio(np.array(values))
    ([0, 2], 6.21)
    """
    r = random.randrange(0, len(asset_values))
    curr_selection = []
    curr_selection.append(r)
    curr_len = 1
    curr_return = compute_return(asset_values[r]) / compute_max_drawdown(asset_values[r])
    curr_asset = asset_values[r]

    flag = True
    while flag == True:
        flag = False

        # check if can add an asset
        for i in range(len(asset_values)):
            if i in curr_selection:
                continue
            add = np.add(curr_asset, asset_values[i]) / (curr_len+1)
            add_performance = compute_return(add) / compute_max_drawdown(add) 
            if add_performance > curr_return:
                curr_selection.append(i)
                curr_len += 1
                curr_asset = add
                curr_return = add_performance
                flag = True
                break
        
        if curr_len == 1:
            continue
        
        # check if can remove an asset 
        for i in curr_selection:
            minus = np.subtract(curr_asset * curr_len, asset_values[i])  / (curr_len - 1)
            minus_performance = compute_return(minus) / compute_max_drawdown(minus)
            if minus_performance > curr_return:
                curr_selection.remove(i)
                curr_len -= 1
                curr_asset = minus
                curr_return = minus_performance
                flag = True
                break
            
    return (curr_selection, curr_return)


def optimize_portfolio_with_restarts(
    asset_values: np.ndarray, num_restarts: int = 10
) -> tuple[list[int], float]:
    """Uses local search with restarts to choose a subset of the assets which maximizes return/risk.

    Parameters
    ----------
    asset_values : np.ndarray[float]
        2D array where row i contains a time series of values for the ith asset.
    num_restarts : int
        Number of times to restart the local search.

    Returns
    -------
    portfolio_assets : list[int]
        Sorted list of indices corresponding to the assets included in the portfolio.
    return_over_risk : float
        Return divided by maximum drawdown (objective function value) for the chosen assets.
    """

    max_return = 0
    max_selection = ()
    for _ in range(num_restarts):
        curr_return = optimize_portfolio(asset_values)
        print("this iter", curr_return)
        if curr_return[1] > max_return:
            max_return = curr_return[1]
            max_selection = curr_return

    return max_selection


# values = [[100, 99, 98, 101, 102], [100, 95, 88, 96, 103], [100, 103, 107, 106, 104], [105, 104, 102, 106, 110]]
# print(optimize_portfolio_with_restarts(values, 10))


# if __name__ == "__main__":
#     import doctest
#     doctest.testmod()

