from cProfile import label
from turtle import color
import numpy as np
import matplotlib.pyplot as plt

from simple_bloom_filter import SimpleBloomFilter
from multi_bloom_filter import MultiBloomFilter
from collision_optimal_mbf import CollisionOptimalMBF

"""
Test the performance of your Bloom Filters.

  - Add r elements uniformly at random from
   [1..N] to your filter.
  - return the bloom filter
"""


def bf_performance_helper(N: int, r: int, capacity: int, hash_func=None):
    S = np.random.choice(np.arange(N), size=r, replace=False)
    bf = SimpleBloomFilter(capacity=capacity, hash_function=hash_func)
    bf.add_all(*S)
    return bf


def mbf_performance_helper(N: int, r: int, capacity: int, k: int, hash_funcs=None):
    S = np.random.choice(np.arange(N), size=r, replace=False)
    bf = MultiBloomFilter(capacity=capacity, k=k, hash_functions=hash_funcs)
    bf.add_all(*S)
    return bf


def co_mbf_performance_helper(N: int, r: int, capacity: int):
    S = np.random.choice(np.arange(N), size=r, replace=False)
    bf = CollisionOptimalMBF(capacity=capacity, n=r)
    bf.add_all(*S)
    return bf


"""
Compare the collision probabilities for each type of filter over
different ranges of r. Each bloom filter should have (approximately) 
the same total capacity.
"""

def collision_prob():
    capacity = 10000
    N = 20000
    step = 1000
    rs = list(range(1000, N + 1, step))

    collision_simple = [bf_performance_helper(N, r, capacity).num_collisions / r for r in rs]

    collision_multi = []
    for k in range(2, 11, 2):
        temp = [(r-mbf_performance_helper(N, r, capacity, k).num_filled/k)/r for r in rs] # num_fill sums over all k sub-filter's, so should times r by k?
        collision_multi.append(temp)

    collision_optimal=[]
    for r in rs:
        bf = co_mbf_performance_helper(N, r, capacity)
        k = len(bf.filters)
        collision_optimal.append((r - bf.num_filled/k)/r)

    collision_optimal = [(r - co_mbf_performance_helper(N, r, capacity).num_filled)/ r for r in rs]

    plt.plot(rs, collision_simple, label = "simple bloom filter")
    plt.plot(rs, collision_multi[0], label = "multiple bloom filter with k=2")
    plt.plot(rs, collision_multi[1], label = "multiple bloom filter with k=4")
    plt.plot(rs, collision_multi[2], label = "multiple bloom filter with k=6")
    plt.plot(rs, collision_multi[3], label = "multiple bloom filter with k=8")
    plt.plot(rs, collision_multi[4], label = "multiple bloom filter with k=10")
    plt.plot(rs, collision_optimal, label = "optimal bloom filter", color="black")
    plt.title("Collision probability")
    plt.legend()
    plt.savefig("./collision_comparison.jpeg")
    plt.close()

"""
Summary: the simple bloom filter seem to yield the highest collision probability.
The collision probability of the optimal filter seem to vary as the number of elements increases.
For multiple bloom filter, the greater the k, the lower the collision probability. 
"""


# compute the (empirical) collision probability for each type
# of bloom filter, and plot the results (you may use matplotlib.pyplot for this)
# Use r for the x axis and collision probability for y.
# For the MultiBloomFilter, you may want to experiment with a few different values of k
# and include the results for each k value in your plot.

# example code for plot and save:
# for each type of filter:
#   ... get collision prob. data for the filter ...
#   plt.plot(rs, collision_prob_data, label = filter.filter_ty)
# plt.legend()
# plt.show()
# plt.save_fig(<path>)


pass  # TODO: Save the plot in ./collision_comparison.jpeg

# Leave a comment explaining your findings below


"""
Repeat the experiment plotting the number of slots filled for each type of filter
"""
def collision_fill():
    capacity = 10000
    N = 20000
    step = 1000
    rs = list(range(1000, N + 1, step))

    collision_simple = [bf_performance_helper(N, r, capacity).num_filled for r in rs]

    collision_multi = []
    for k in range(2, 11, 2):
        temp = [mbf_performance_helper(N, r, capacity, k).num_filled for r in rs]
        collision_multi.append(temp)

    collision_optimal = [co_mbf_performance_helper(N, r, capacity).num_filled for r in rs]

    plt.plot(rs, collision_simple, label = "simple bloom filter")
    plt.plot(rs, collision_multi[0], label = "multiple bloom filter with k=2")
    plt.plot(rs, collision_multi[1], label = "multiple bloom filter with k=4")
    plt.plot(rs, collision_multi[2], label = "multiple bloom filter with k=6")
    plt.plot(rs, collision_multi[3], label = "multiple bloom filter with k=8")
    plt.plot(rs, collision_multi[4], label = "multiple bloom filter with k=10")
    plt.plot(rs, collision_optimal, label = "optimal bloom filter", color="black")
    plt.title("Number of slots filled")
    plt.legend()
    plt.savefig("./fill_comparison.jpeg")
    plt.close()

collision_prob()
collision_fill()

# TODO: Save the plot in ./fill_comparison.jpeg

# Leave a comment explaining your findings below -
# Is this what you expect after seeing the results from the first plot?
"""
Comment:
The number of bits filled for the optimal filter is the least,
which corresponds to the low collision probabililty in the first graph. 
In addition, for multiple bloom filters, the smaller the k, the less the bits filled.
"""