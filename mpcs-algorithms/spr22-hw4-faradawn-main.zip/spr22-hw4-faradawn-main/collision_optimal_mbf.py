from multi_bloom_filter import MultiBloomFilter


class CollisionOptimalMBF(MultiBloomFilter):
    """A MultiBloomFilter that is optimized to minimize collision probability.

    This class takes a capacity and n (the expected number of items to add)
    as parameters and returns a multi-bloom-filter with k sub-filters,
    where k is chosen to minimize the likelihood of collisions.

    You must only implement code to find the optimal such k
    (given an overall capacity and expected number of items).

    Please list the rationale for your choice of k in the docstring.
    Floors and ceilings can be ignored in the analysis.
    """

    def __init__(self, capacity: int, n: int):
        k = self.get_optimal_k(capacity, n)
        super().__init__(capacity=capacity, k=k)

    @staticmethod
    def get_optimal_k(capacity: int, n: int) -> int:
        """
        Let m be the length of each sub-filter 

        First, calculate the expected number of ones in each sub-filter after n elements are added.
        That is done by 1 - (prob of not hitting this bit)^n; then times m, because there are m bits.

        Second, calculate the false positive rate after n elements are added.
        That is done by (expected_ones in the sub-filter / length of the sub-filter)^k, 
        where raising to the power of k means hitting an already-set-one in all k sub-filters 

        Finally, we try all possible values of k.
        If the false positive probability of this k is less than the min false prob,
        we set the min false prob to this false prob and record the best k.
        """
        min_prob = 1
        best_k = 1
        for k in range(1, capacity):
            m = capacity // k
            expected_ones = m * (1 - pow((1 - 1/m), n)) 
            false_prob = pow((expected_ones / m), k)
            if false_prob < min_prob:
                min_prob = false_prob
                best_k = k
        return best_k


        # min_prob = 10000
        # best_k = 1
        # for k in range(1, capacity):
        #     m = capacity // k
        #     sum = 0
        #     for i in range(1, n):
        #         sum += pow((i/m), k)
        #     if sum < min_prob:
        #         min_prob = sum
        #         best_k = k
        #     print("this prob", sum)
        # print("best k", best_k)
        # return best_k



# Simple test code
if __name__ == "__main__":
    from random import randint

    n = 50
    capacity = 50
    items = [randint(0, 2 ** 31 - 1) for _ in range(n)]
    bf = CollisionOptimalMBF(capacity, n)
    bf.add_all(*items)
    tests = [randint(0, 2 ** 31 - 1) for _ in range(10)]
    print(f"All items included: {all(i in bf for i in items)}")
    for t in tests:
        print(f"{t} in bf: {t in bf}")
