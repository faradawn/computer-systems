from __future__ import annotations

import networkx as nx
import warmup


def max_weighted_clique(graph: nx.Graph) -> tuple:
    """Finds a maximum-weight clique in a graph with non-negative vertex weights.

    Note: We are interested in the clique with maximum total weight.
    This is not necessarily the same as the clique with the maximum number of vertices.

    :param graph: A NetworkX Graph where vertices have a "weight" attribute.
    :return clique: A list or tuple of vertices constituting a largest vertex weighted clique in the graph.
    """
    vertices=list(graph.nodes)
    max_val=-1
    max_vertices=()

    # size 1 clique
    for k in vertices:
        if graph.nodes[k]["weight"] > max_val:
            max_val=graph.nodes[k]["weight"]
            max_vertices=(k,)

    # size 2 to size n-1 clique
    for k in range(2, len(vertices)):
        for tup in warmup.generate_subsets(vertices, k):
            sum=0
            isClique=1
            for i in tup:
                for j in tup:
                    if j != i and j not in list(graph.adj[i]):
                        isClique=0
                        break
                else:
                    sum+=graph.nodes[i]["weight"]
                    continue
                break
                        

            if isClique:
                print("+++ is clique", tup, "sum", sum)
                if sum > max_val:
                    max_val=sum
                    max_vertices=tup
    return max_vertices
    

def longest_path(graph: nx.Graph) -> tuple:
    """Finds a longest simple path in a graph with non-negative edge weights. Directed graph!!

    :param graph: A NetworkX Graph where edges have a "weight" attribute.
    :return path: A list or tuple of vertices constituting a longest path in the graph.
    """

    longest_val=0
    longest_path=()

    vertices=list(graph.nodes)
    n=len(vertices)
    for path in warmup.generate_permutations(vertices):
        sum=0
        for i in range(n-1):
            if path[i+1] in graph.adj[path[i]]:
                sum+=graph.adj[path[i]][path[i+1]]["weight"]
            else:
                path=tuple(path[:i+1])
                break
        if sum >= longest_val:
            longest_val=sum
            longest_path=path

    return longest_path


def knapsack_01(capacity: float, values: list[float], weights: list[float]) -> tuple[int]:
    """Maximize the value in the knapsack given the item values and capacity constraint.

    Note: We are interested in solving the 0-1 knapsack problem where the capacity and weights are not restricted to integer values.

    :param capacity: The capacity of the knapsack.
    :param values: The values for each item.
    :param weights: The weights for each item.
    :return items: A list or tuple of integers specifying the item numbers/indices making the best value knapsack given the capacity constraints.
    """
    assert len(weights) == len(values)
    assert len(weights) == len(values)
    s=[i for i in range(len(weights))]
    print(s)
    max_val=0
    max_items=()
    for i in warmup.generate_powerset(s):
        w=0
        v=0
        for j in i:
            w+=weights[j]
            v+=values[j]
        if w <= capacity:
            if v > max_val:
                max_val=v
                max_items=i
                print(max_val, max_items)
    return max_items