# Comparison of Christofides and Two-opt

## Plots of Runtime vs. Vertices and Weight vs. Vertices
### vertices 10 - 200
![](mine/graph_200.png)

### vertices 10 - 100
![](mine/graph_110.png)



## Analysis
Based on the comparison, Two-opt seems to achieve lower total weights, and Christofides better runtime. 

Christofides has considerable faster runtime but slightly higher total weight. 
The stability of its performance and constant approximation ratio renders it suitable for larger graphs. 
In addition, Christofides' runtime doesn't scale exponentially with number of vertices. 

Two-opt, on the other hand, has a runtime that increases proportionally with number of vertices. 
However, it often finds a smaller-weight path than Christofides -- perhaps because it permutes all possibilties of paths?
In every iteration (the loop of 'while improved'), two-opt tries all possible pairwise edge swaps, which is O(n^2). Then, it calculates the new weight sum,
which times another n. Therefore, as every while-loop is O(n^3) and there are at most nCr(E, 4) = n^4 improvements (maybe?), the total runtime is O(n^7).

Hence, in practice, for large graphs, Christofides is more suitable. 
