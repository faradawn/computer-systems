import numpy as np
from utils import generate_metric_graph
from main import christofides, two_opt, cal_weight
import time
import matplotlib.pyplot as plt 
import numpy as np 

def run_tests(start,end,step_size):
    vertices=[i for i in range(start,end,step_size)]
    time1=[]
    time2=[]
    weight1=[]
    weight2=[]

    for i in vertices:
        print(i)
        g=generate_metric_graph(i, seed=10)
        start = time.time()
        c=christofides(g)
        end = time.time()
        time1.append(end-start)
        weight1.append(cal_weight(c,g))

        start = time.time()
        c=two_opt(g)
        end = time.time()
        time2.append(end-start)
        weight2.append(cal_weight(c,g))

    arr1=np.array([vertices, time1, weight1])
    arr2=np.array([vertices, time2, weight2])
    np.savetxt("./mine/out1_{0}".format(end), arr1)
    np.savetxt("./mine/out2_{0}".format(end), arr2)

def generate_graph(end):
    arr1=np.loadtxt("./mine/out1_{0}".format(end))
    arr2=np.loadtxt("./mine/out2_{0}".format(end))

    # subplots
    figure, (ax1, ax2) = plt.subplots(2) 
    figure.set_size_inches(8, 8)


    ax1.set_title("Time vs Vertices (Christofides is blue, Two-opt is orange)") 
    ax1.plot(arr1[0], arr1[1], label="Christofides time", color="blue") 
    ax1.plot(arr2[0], arr2[1], label="Two-opt time", color="orange") 

    ax2.set_title("Weight vs Vertices (Christofides is blue, Two-opt is orange)")
    ax2.plot(arr1[0], arr1[2], label="Christofides weight", color="blue")
    ax2.plot(arr1[0], arr2[2], label="Two-opt weight", color="orange")

    plt.savefig("./mine/graph_{0}.png".format(end))
    plt.show()
    plt.close(figure)


num=110
run_tests(10, num, 10)
generate_graph(num)


