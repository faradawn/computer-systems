from __future__ import annotations
from distutils.dep_util import newer_group
from email.errors import MultipartInvariantViolationDefect
from multiprocessing.spawn import old_main_modules
from queue import PriorityQueue

from typing import Hashable

import networkx as nx

from utils import check_cycle, generate_metric_graph
import tsplib95
import time

def prim(G: nx.Graph):
    Q=PriorityQueue()
    V=set()
    Tree_G=nx.Graph()

    s=list(G.nodes)[0]
    V.add(s)
    for w in G.neighbors(s):
        if G[s][w]["weight"] != 0:
            Q.put((G[s][w]["weight"], (s, w)))

    while len(V) < G.number_of_nodes():
        ww,e=Q.get(Q)

        u=e[0]
        if e[0] in V and e[1] in V:
            continue
        if e[1] not in V:
            u=e[1]

        V.add(u)
        Tree_G.add_edge(e[0],e[1], weight=ww)
        for w in G.neighbors(u):
            if G[u][w]["weight"] != 0:
                Q.put((G[u][w]["weight"], (u, w)))

    return Tree_G

def odd_deg_graph(MST: nx.Graph, G:nx.Graph):
    Induced_G=G.copy()
    for v, val in MST.degree():
        if val % 2 == 0:
            Induced_G.remove_node(v)
    return Induced_G

def add_to_mst(MST: nx.Graph, M: set, G: nx.Graph):
    multi_MST=nx.MultiDiGraph(MST)
    for e in M:
        multi_MST.add_edge(e[0], e[1], weight=G[e[0]][e[1]]["weight"])
    multi_MST=multi_MST.to_undirected()
    return multi_MST

def remove_repeat(euler_cycle: list):
    temp=set()
    path=[]
    
    for e in euler_cycle:
        if e[0] not in temp:
            temp.add(e[0])
            path.append(e[0])
        if e[1] not in temp:
            temp.add(e[1])
            path.append(e[1])

    path.append(euler_cycle[0][0])
    return path

def sum_weight(path: list, G: nx.Graph):
    sum=0
    for i in range(len(path)-1):
        sum+=G[path[i]][path[i+1]]["weight"]
    return sum

def cal_weight(cycle: list, graph: nx.Graph):
    return sum(graph[u][v]["weight"] for u, v in zip(cycle, cycle[1:]))

def christofides(graph: nx.Graph) -> list[Hashable]:
    # clear self-looping edges
    G=graph.to_undirected()
    # for v in list(G.nodes):
    #     G.remove_edge(v,v)
    
    # produce MST
    MST=prim(G)

    # the induced graph that contains only odd-degree vertices
    Odd_G=odd_deg_graph(MST, G)

    # find min-weight-matching
    M=nx.min_weight_matching(Odd_G)

    # add to MST
    Multi_MST=add_to_mst(MST, M, G)

    # find euler cycle
    euler_cycle=list(nx.eulerian_circuit(Multi_MST))

    # remove repeated vertices
    path=remove_repeat(euler_cycle)

    return path


def swap_2opt(route, i, k): # maybe can use for loop to improve performance?
    new_route = route[0:i]
    new_route.extend(reversed(route[i:k + 1]))
    new_route.extend(route[k + 1:])
    return new_route

def two_opt(graph: nx.Graph) -> list[Hashable]:
    min_route=list(graph.nodes)
    min_route.append(min_route[0])
    min_weight=cal_weight(min_route, graph)
    n=len(min_route)
    flag=1

    while flag == 1:
        flag=0
        for i in range(1, n-1):    
            for j in range(i+1, n-1):
                new_route=swap_2opt(min_route, i, j)
                new_weight=cal_weight(new_route, graph)
                if new_weight < min_weight:
                    min_route=new_route
                    min_weight=new_weight
                    flag=1
                    break
            if flag==1:
                break
        
    return min_route




# print(check_cycle(g, two_opt(g), optimum=5, approximation_ratio=3**0.5))

time1=[]
time2=[]
weight1=[]
weight2=[]

for i in range(10,101,10):
    print(i)
    g=generate_metric_graph(i, seed=10)
    start = time.time()
    c=christofides(g)
    end = time.time()
    time1.append(end-start)
    weight1.append(cal_weight(c,g))

    start = time.time()
    w=two_opt(g)
    end = time.time()
    time2.append(end-start)
    weight2.append(cal_weight(c,g))


print(time1)
print(weight1)
print(time2)
print(weight2)



          


if __name__ == "__main__":
    import doctest

    doctest.testmod()
