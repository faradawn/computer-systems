import pytest

import numpy as np
import mw_variants as mw


def test_adaptive_update_weights(
    in_weights, in_predictions, in_outcome, out_weights_adaptive
):
    assert len(in_weights) == len(in_predictions)

    mul_weights = mw.AdaptiveWeightedMajority()
    mul_weights.weights = in_weights

    mul_weights.update_weights(in_predictions, in_outcome)
    assert np.allclose(mul_weights.weights, out_weights_adaptive)

