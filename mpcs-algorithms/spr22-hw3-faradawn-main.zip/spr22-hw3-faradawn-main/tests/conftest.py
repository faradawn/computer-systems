import pytest

import numpy as np
import os


@pytest.fixture(scope="module", params=range(7))
def test_number(request):
    return request.param


@pytest.fixture(scope="module")
def in_weights(test_number):
    return {
        0: np.array([1.]),
        1: np.array([1., 1, 1, 1]),
        2: np.array([1., 1, 1, 1]),
        3: np.array([0.5, 0.5, 1]),
        4: np.array([0.5, 0.5, 1]),
        5: np.array([1, 1, 1, 1, 0.2]),
        6: np.array([1, 1, 1, 1, 0.2]),
    }[test_number]


@pytest.fixture(scope="module")
def in_predictions(test_number):
    return {
        0: np.array([-1]),
        1: np.array([1, -1, -1, -1]),
        2: np.array([1, -1, 1, -1]),
        3: np.array([1, 1, -1]),
        4: np.array([-1, 1, 1]),
        5: np.array([1, 1, 1, 1, -1]),
        6: np.array([1, 1, 1, 1, 1]),
    }[test_number]


@pytest.fixture(scope="module")
def in_outcome(test_number):
    return {0: 1, 1: 1, 2: -1, 3: 1, 4: 1, 5: 1, 6: -1,}[test_number]


@pytest.fixture(scope="module")
def out_decision_deterministic(test_number):
    return {0: [-1], 1: [-1], 2: [1, -1], 3: [1, -1], 4: [1], 5: [1], 6: [1],}[
        test_number
    ]


@pytest.fixture(scope="module")
def out_decision_randomized(test_number):
    return {0: 0, 1: 0.25, 2: 0.5, 3: 0.5, 4: 0.75, 5: 4 / 4.2, 6: 1}[test_number]


@pytest.fixture(scope="module")
def out_weights_standard(test_number):
    return {
        0: np.array([0.5]),
        1: np.array([1, 0.5, 0.5, 0.5]),
        2: np.array([0.5, 1, 0.5, 1]),
        3: np.array([0.5, 0.5, 0.5]),
        4: np.array([0.25, 0.5, 1]),
        5: np.array([1, 1, 1, 1, 0.1]),
        6: np.array([0.5, 0.5, 0.5, 0.5, 0.1]),
    }[test_number]


@pytest.fixture(scope="module")
def out_weights_adaptive(test_number):
    return {
        0: np.array([0.5]),
        1: np.array([1, 0.5, 0.5, 0.5]),
        2: np.array([0.5, 1, 0.5, 1]),
        3: np.array([0.5, 0.5, 0.5]),
        4: np.array([0.25, 0.5, 1]),
        5: np.array([1, 1, 1, 1, 0.2]),
        6: np.array([0.5, 0.5, 0.5, 0.5, 0.2]),
    }[test_number]
