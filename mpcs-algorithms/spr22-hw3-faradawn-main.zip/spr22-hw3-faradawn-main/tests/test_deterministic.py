import pytest

import numpy as np
import mw_variants as mw


def test_deterministic_get_decision(
    in_weights, in_predictions, out_decision_deterministic
):
    assert len(in_weights) == len(in_predictions)

    mul_weights = mw.WeightedMajority()
    mul_weights.weights = in_weights

    result = mul_weights.get_decision(in_predictions)
    assert result in out_decision_deterministic


def test_standard_update_weights(
    in_weights, in_predictions, in_outcome, out_weights_standard
):
    assert len(in_weights) == len(in_predictions)

    mul_weights = mw.WeightedMajority()
    mul_weights.weights = in_weights

    mul_weights.update_weights(in_predictions, in_outcome)
    assert np.allclose(mul_weights.weights, out_weights_standard)
