import pytest

import numpy as np
import mw_variants as mw

ITERS = 10000
SLACK = 1.05


def test_randomized_get_decision(in_weights, in_predictions, out_decision_randomized):
    assert len(in_weights) == len(in_predictions)

    mul_weights = mw.RandomizedWeightedMajority()

    result = 0

    for _ in range(ITERS):
        mul_weights.weights = in_weights
        decision = mul_weights.get_decision(in_predictions)
        assert decision == 1 or decision == -1
        if decision == 1:
            result += 1

    result /= ITERS
    assert out_decision_randomized / SLACK <= result <= out_decision_randomized * SLACK

