from __future__ import annotations

import numpy as np
import numpy.typing as npt

from expert import Sign
from multiplicative_weights import MultiplicativeWeights

import random


class WeightedMajority(MultiplicativeWeights):
    """Standard, deterministic variant of the multiplicative weights algorithm."""

    def get_decision(self, predictions: npt.NDArray[Sign]) -> Sign:
        """Makes a decision using the weighted majority of the expert predictions.

        Parameters
        ----------
        predictions : np.ndarray[Sign]
            Array where predictions[i] contains the prediction made by self.experts[i].

        Returns
        -------
        decision : Sign
            Decision (1 to buy, -1 to sell) based upon weighted majority of expert opinions.
        """
        sum = 0.0
        for i in range(len(self.weights)):
            sum+=self.weights[i] * predictions[i]

        if sum >= 0.0:
           return 1
        else:
            return -1

    def update_weights(self, predictions: npt.NDArray[Sign], outcome: Sign) -> None:
        """Applies standard MW update rule: halves the weight of each incorrect expert.

        Parameters
        ----------
        predictions : np.ndarray[Sign]
            Array where predictions[i] contains the prediction made by self.experts[i].
        outcome : Sign
            Outcome to compare against the predictions.
        """
        for i in range (len(predictions)):
            if predictions[i] != outcome:
                self.weights[i] /= 2


class RandomizedWeightedMajority(WeightedMajority):
    """Randomized variant of the multiplicative weights algorithm.

    When making a decision, flips a biased coin weighted according to the experts' predictions.

    Uses the same update rule as standard multiplicative weights.
    """

    def __init__(self, seed: int | None = None, **kwargs):
        super().__init__(**kwargs)
        self.rng = np.random.default_rng(seed)

    def get_decision(self, predictions: npt.NDArray[Sign]) -> Sign:
        """Decides using randomized weighted majority of the expert predictions.

        Parameters
        ----------
        predictions : np.ndarray[Sign]
            Array where predictions[i] contains the prediction made by self.experts[i].

        Returns
        -------
        decision : Sign
            Decision (1 to buy, -1 to sell) based upon weighted majority of expert opinions.
        """
        sum_yes = 0.0
        sum_no = 0.0
        for i in range(len(self.weights)):
            if predictions[i] == 1:
                sum_yes += self.weights[i]
            else:
                sum_no += self.weights[i]
        
        yes_prob = sum_yes / (sum_yes + sum_no)

        if random.uniform(0,1) < yes_prob:
            return 1
        else:
            return -1

        
        


class AdaptiveWeightedMajority(WeightedMajority):
    """Adaptive variant of the multiplicative weights algorithm.

    Does not apply weight penalty to incorrect experts with low weight.
    These experts are exempted to prevent them from falling into total irrelevance.

    Uses the same decision rule as standard multiplicative weights.
    """

    def __init__(self, mercy_factor: float = 0.25, **kwargs):
        """Initializes the adaptive variant of multiplicative weights.

        Parameters
        ----------
        mercy_factor : float
            Factor used to decide whether to apply weight penalty to experts making a mistake.
            If the expert's weight is below mean_weight * mercy_factor, they are pardoned.
        """
        super().__init__(**kwargs)
        self.mercy_factor = mercy_factor

    def update_weights(self, predictions: npt.NDArray[Sign], outcome: Sign) -> None:
        """Applies adaptive MW update rule, exempting experts who already have low weight.

        Parameters
        ----------
        predictions : np.ndarray[Sign]
            Array where predictions[i] contains the prediction made by self.experts[i].
        outcome : Sign
            Outcome to compare against the predictions.
        """
        total_weights = sum(self.weights)

        for i in range (len(predictions)):
            if predictions[i] != outcome:
                if self.weights[i] >= (1.0/4.0) * total_weights:
                    self.weights[i] /= 2
