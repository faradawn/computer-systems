# Comparision of Three Types of Majority Weight Algorithms

## Graphs of the number of mistakes

![](comparison_graph.png)

## Analysis 
Comparing the performances of the three algorithms, the Adaptive variant seems to make the fewest number of mistakes. This is expected by the Adaptive variant to protect the poor experts' weight from sinking to the bottom, thereby giving them a chance to recover in the future. Thus, in the long run, the Adaptive variant keeps all experts alive which injects more balance into the decision. 

The second is the Deterministic variant, which updates the experts' weights in a strict manner. As it punishes the incorrect experts more, the experts that rely on the past data, such as Mean Reversion and Rational Hottest, might be reduced to little weight at first, if the start date is early or window small.

The third is the Randomized variant, which has the greatest volatility due to is the involvement of flipping a coin, even though weighted. Sometimes, the Randomized variant performs exceedingly well. Yet the lack of stability renders it not the best choice for stock prediction. 
