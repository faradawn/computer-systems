from typing import TypedDict

import numpy.typing as npt


class StockData(TypedDict):
    volume: npt.NDArray[float]
    open: npt.NDArray[float]
    low: npt.NDArray[float]
    high: npt.NDArray[float]
    close: npt.NDArray[float]
    date: npt.NDArray[str]
