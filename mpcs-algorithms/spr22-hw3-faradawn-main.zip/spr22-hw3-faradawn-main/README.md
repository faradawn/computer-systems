# Multiplicative Weights

[Multiplicative weights](https://en.wikipedia.org/wiki/Multiplicative_weight_update_method) 
is an algorithmic technique which aggregates advice from several "experts" in order to 
make a sequence of binary decisions or predictions. 
It is a classic example of [online learning](https://en.wikipedia.org/wiki/Online_machine_learning).


The central idea is to assign different weights to each expert's opinion, use a weighted average 
to make each decision, and update the weights based upon the observed outcome.
The number of mistakes *M* made by the algorithm can be bounded in terms of the fewest mistakes 
*m* made by the best individual expert.

For this assignment, you will implement multiplicative weights to predict whether stock prices 
will go up or down. A pseudocode outline is as follows:

![](pseudocode.png)

You will be given data of daily open, high, low, and close 
([OHLC](https://en.wikipedia.org/wiki/Open-high-low-close_chart)) prices as well as volumes 
for two stocks, GE and MSFT.

For simplicity, assume that we are trading intraday only, 
i.e. we will buy during the open and sell during the close.
This means we can ignore after-hours trading and overnight price changes.

## Implementation

### Dependencies

You will need NumPy 1.21 or greater for its 
[typing features](https://numpy.org/devdocs/reference/typing.html),
although you can remove the type hints in question if needed.

### Deterministic variant (Weighted Majority)

Your first task is to implement the algorithm above in `mw_variants.py`. 
Most of the framework is already provided for you in an abstract base class. 
Please complete all TODOs in the `WeightedMajority` class.

**Note:** Given the geometric decay of expert weights, underflow is likely to occur, 
so the abstract base class contains code which rescales the weights periodically.

A few basic experts are available for testing purposes in `expert.py`.
For a full example of how to load data and use the algorithm, see `example.py`.

### Randomized variant (Randomized Weighted Majority)

A natural idea is to treat the weights as probabilities and use randomization to make decisions.
For example, if experts with 60% of the total weight vote yes, and 40% vote no, flip a biased coin.
In expectation, this algorithm makes fewer mistakes than deterministic weighted majority.

Please complete all TODOs in the `RandomizedWeightedMajority` class.

### Adaptive variant

We also consider an "adaptive" variant of multiplicative weights, 
where each weight *w<sub>i</sub>* is only reduced if 
*w<sub>i</sub>* is at least 1/4 of the average weight at the current time step.
This variant allows experts to recover from a long history of poor predictions,
whereas the standard variant would ignore such experts.
The adaptive version of multiplicative weights responds better to regime changes in the data.

For example, suppose an expert makes the wrong prediction for 100 days straight, 
and then makes the right prediction for 50 days straight.
The standard variant would give this expert's opinion nearly zero weight during both phases.
The adaptive version would mostly ignore this expert during the first phase, 
but listen to the expert during the second phase once its weight has recovered.

This idea is due to [Avrim Blum](https://en.wikipedia.org/wiki/Avrim_Blum).

Please complete all TODOs in the `AdaptiveWeightedMajority` class.


## Custom experts

Next, you must create new "experts" which predict the direction a stock will move given 
data for previous days. These can be as simple or as complicated as you like.
Your solution will be graded on creativity and implementation quality.

## Comparison

Finally, please analyze the results of each variant of multiplicative weights
on the stock price data using the experts and time period(s) of your choice. 
Compare the number of mistakes made by the algorithms to the number of mistakes made by the best expert.
