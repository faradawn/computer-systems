"""
Example code for adding experts and running the multiplicative weights algorithm.
"""
from __future__ import annotations
from numbers import Rational

import numpy as np
import matplotlib.pyplot as plt 

from expert import Expert, Hottest, MeanReversion, RationalHottest, YesterdaysNews, ExpectationExpert
from mw_variants import AdaptiveWeightedMajority, RandomizedWeightedMajority, WeightedMajority
from stock_data import StockData


# Load the data
path_to_data = 'data/stock_data.npy'
dataset: dict[str, StockData] = np.load(path_to_data, allow_pickle=True).item()

days=[i for i in range(10, 110, 5)]

def run():
    mw1_mistakes=[]
    mw2_mistakes=[]
    mw3_mistakes=[]

    best1_mistakes=[]
    best2_mistakes=[]
    best3_mistakes=[]

    for i in days:
        experts: list[Expert] = [YesterdaysNews(), Hottest(), RationalHottest(), RationalHottest()]
        start_day = i
        max_window = min(start_day, 20)
        for window in range(1, max_window+1):
            e1 = MeanReversion(window)
            e2 = ExpectationExpert(window)
            experts += [e1, e2]

        mw1 = WeightedMajority(learning_rate=0.5)
        mw2 = RandomizedWeightedMajority(learning_rate=0.5)
        mw3 = AdaptiveWeightedMajority(learning_rate=0.5)

        stock_data = dataset["MSFT"]
        data = mw1.get_data_in_range(stock_data, 0, 300)

        for e in experts:
            mw1.add_expert(e)
            mw2.add_expert(e)
            mw3.add_expert(e)

        tup1 = mw1.run(data, start_day=start_day)
        tup2 = mw2.run(data, start_day=start_day)
        tup3 = mw3.run(data, start_day=start_day)

        mw1_mistakes.append(tup1[0])
        mw2_mistakes.append(tup2[0])
        mw3_mistakes.append(tup3[0])

        best1_mistakes.append(tup1[1])
        best2_mistakes.append(tup2[1])
        best3_mistakes.append(tup3[1])
    

    figure, (ax1, ax2) = plt.subplots(2) 
    figure.set_size_inches(8, 8)
    figure.suptitle("blue is Deterministic, orange is Randomized, green is Adaptive")

    ax1.set_title("Number of mistakes vs start day") 
    ax1.plot(days, mw1_mistakes, color="blue") 
    ax1.plot(days, mw2_mistakes, color="orange") 
    ax1.plot(days, mw3_mistakes, color="green") 

    ax2.set_title("Best expert's mistakes vs start day") 
    ax2.plot(days, best1_mistakes, color="blue") 
    ax2.plot(days, best2_mistakes, color="orange") 
    ax2.plot(days, best3_mistakes, color="green") 

    plt.savefig("graph_{0}.png".format(1))
    plt.show()
    plt.close(figure)

run()

