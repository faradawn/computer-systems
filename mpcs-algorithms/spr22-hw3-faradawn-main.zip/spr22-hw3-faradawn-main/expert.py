from __future__ import annotations

from abc import ABC
from fileinput import close
from typing import Literal

import numpy as np

from stock_data import StockData
import random

 
Sign = Literal[1, -1]


class Expert(ABC):
    """Experts must predict whether stock price will go up or down based on historical data."""

    def predict(self, data: StockData) -> Sign:
        pass


class YesterdaysNews(Expert):
    """Naive strategy: predicts price will move in the same direction as it did yesterday."""

    def predict(self, data: StockData) -> Sign:
        if not data or data["close"][-1] > data["open"][-1]:
            return 1
        else:
            return -1


class ExpectationExpert(Expert):
    """Predicts price movements based upon recent trends.

    For example, if the price went up on most days recently, we might predict it will go up again.
    See also: https://en.wikipedia.org/wiki/Trend_trading

    Generalizes the YesterdaysNews expert to longer time windows.
    """

    def __init__(self, window=5, sign: Sign = 1):
        """Initializes the ExpectationExpert with the given parameters.

        Parameters
        ----------
        window : int
            Number of time steps to look back when computing mean.
        sign : Sign
            Defaults to 1 to predict price will move in same direction as recent trend.
            Can be set to -1 to invert behavior and predict that price will move opposite to trend.
        """
        self.window = window
        self.sign: Sign = sign

    def predict(self, data: StockData) -> Sign:
        window = self.window
        daily_changes = zip(data["open"][-window:], data["close"][-window:])
        pos_prob = np.array([np.sign(b-a) for a, b in daily_changes])
        sign = self.sign
        return sign if len(pos_prob[pos_prob > 0]) > len(pos_prob[pos_prob < 0]) else -sign


class MeanReversion(Expert):
    """Predicts price movements based upon a longer-term average.

    For example, if yesterday's close is above the long term average, predict it will go down.
    See also: https://en.wikipedia.org/wiki/Mean_reversion_(finance)
    """

    def __init__(self, window: int = 5, sign: Sign = 1):
        """Initializes the MeanReversion expert with the given parameters.

        Parameters
        ----------
        window : int
            Number of time steps to look back when computing mean.
        sign : Sign
            Defaults to 1 to predict price will move up if it is below average over the window.
            Can be set to -1 to invert behavior and predict that price will move *away* from mean.
        """
        self.window = window
        self.sign: Sign = sign

    def predict(self, data: StockData) -> Sign:
        temp = data["close"]
        window = self.window
        return self.sign if temp[-1] < np.mean(temp[-window:]) else -self.sign


class Hottest(Expert):
    """
    If the average volume of the last five days exceeds the historical average,
    return +1.
    """
    def predict(self, data: StockData) -> Sign:
        k = len(data["volume"]) - 6
        historical_volume = np.mean(data["volume"][:k])
        five_day_volume = np.mean(data["volume"][k:])
        if five_day_volume > historical_volume:
            return +1
        else:
            return -1

class RationalHottest(Expert):
    """
    If the past-five-day volume exceeds the historical average
    and the stock price is rising, return +1;
    If the past-five-day is hot
    but the stock price is dropping, return -1;
    Else, flip a 50% coin.
    """

    def predict(self, data: StockData) -> Sign:
        k = len(data["volume"]) - 6
        historical_volume = np.mean(data["volume"][:k])
        five_day_volume = np.mean(data["volume"][k:])
        hotness = np.sign(five_day_volume - historical_volume)
        trend = np.sign(data["close"][-1] - data["open"][k])
        if hotness >= 0 and trend >= 0:
            return +1
        elif hotness > 0 and trend < 0:
            return -1
        else:
            return np.sign(random.uniform(0,1) - 0.5)
        


if __name__ == "__main__":
    pass
