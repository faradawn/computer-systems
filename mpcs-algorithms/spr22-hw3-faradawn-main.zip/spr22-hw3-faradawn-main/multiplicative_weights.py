from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np
import numpy.typing as npt

from expert import Expert, Sign
from stock_data import StockData


class MultiplicativeWeights(ABC):

    def __init__(self, learning_rate: float = 0.5):
        """Initializes a multiplicative weights variant.
        Parameters
        ----------
        learning_rate : float
            Learning rate in [0, 1), often denoted η (eta) or ε (epsilon) in the literature.
            If an expert makes a mistake, their weight is multiplied by (1 - learning_rate).
            Defaults to 0.5. Higher values are more aggressive, lower values are more conservative.
        """
        if not 0 <= learning_rate < 1:
            raise ValueError("Learning rate must be between 0 (inclusive) and 1 (exclusive)!")
        self.learning_rate = learning_rate
        self.experts: list[Expert] = []
        self.weights = None

    def add_expert(self, expert: Expert):
        self.experts.append(expert)

    def reset_weights(self):
        self.weights = np.ones(len(self.experts))

    def get_predictions(self, data) -> npt.NDArray[Sign]:
        return np.array([e.predict(data) for e in self.experts])

    @abstractmethod
    def get_decision(self, predictions: npt.NDArray[Sign]) -> Sign:
        """Aggregates expert opinions in order to make a decision.
        Parameters
        ----------
        predictions : np.ndarray[Sign]
            Array where predictions[i] contains the prediction made by self.experts[i].
        Returns
        -------
        decision : Sign
            Decision (1 to buy, -1 to sell) based upon weighted majority of expert opinions.
        """
        raise NotImplementedError

    @abstractmethod
    def update_weights(self, predictions: npt.NDArray[Sign], outcome: Sign) -> None:
        """Updates expert weights according to their predictions and the actual outcome.
        Parameters
        ----------
        predictions : np.ndarray[Sign]
            Array where predictions[i] contains the prediction made by self.experts[i].
        outcome : Sign
            Actual outcome (1 if the stock price went up, -1 if the stock price went down).
        """
        raise NotImplementedError

    def scale_weights(self) -> None:
        """Scales weights to avoid underflow."""
        max_wt = np.max(self.weights)
        self.weights -= max_wt
        self.weights += 1
        min_wt = np.min(self.weights)
        if min_wt < 2**(-20):
            self.weights[self.weights < 2**(-20)] = 2**(-20)

    @staticmethod
    def get_outcome(data: StockData, t: int) -> Sign:
        """Returns 1 if stock price went up on day t, or -1 if it went down."""
        assert 0 < t < len(data["close"])
        if data["open"][t] > data["close"][t]:
            return -1
        return 1

    def get_reward(self, data: StockData, t: int, decision: Sign) -> float:
        """Computes reward based upon decision at a given time step."""
        outcome = self.get_outcome(data, t)
        abs_price_movement = abs(data["close"][t] - data["open"][t])
        reward = outcome * decision * abs_price_movement
        print(f"Day {t}: decided {decision:+d}, observed {outcome:+d}, PnL {reward:+.2f}")
        return reward

    @staticmethod
    def get_data_up_to_t(data: StockData, t: int) -> StockData:
        """Gets historical data for timestamps 1..t-1, ending at time step t (exclusive)."""
        return {key: data[key][:t] for key in data}

    @staticmethod
    def get_data_from_t(data: StockData, t: int) -> StockData:
        """Gets future data for timestamps t..n, starting at time step t (inclusive)."""
        return {key: data[key][t:] for key in data}

    def get_data_in_range(self, data: StockData, start: int, end: int):
        """Gets data for timestamps start..end-1. Note that the end is excluded."""
        temp = self.get_data_up_to_t(data, end)
        temp = self.get_data_from_t(temp, start)
        return temp

    def get_mistakes(self, data: StockData, start_day: int, decisions) -> int:
        num_steps = len(data["close"]) - start_day
        ground_truth = [self.get_outcome(data, start_day + t) for t in range(num_steps)]
        ground_truth, decisions = np.asarray(ground_truth), np.asarray(decisions)
        return len(ground_truth[ground_truth != decisions])

    def get_rewards(self, data, start_day, decisions) -> float:
        num_steps = len(data["close"]) - start_day
        return sum([self.get_reward(data, start_day+t, decisions[t]) for t in range(num_steps)])

    def run(self, data: StockData, start_day: int = 20) -> None:
        assert len(data["close"]) == len(data["open"])
        num_days_in_dataset = len(data["close"])
        print(f"Found {num_days_in_dataset} days in dataset, numbered 0..{num_days_in_dataset-1}")
        num_steps = num_days_in_dataset - start_day
        if num_steps <= 0:
            raise ValueError("Start day must be less than number of days in dataset")
        print(f"Running for {num_steps} days starting on day {start_day}")

        self.reset_weights()
        total_mistakes = 0
        expert_mistakes = np.zeros(len(self.experts), dtype=int)
        decisions: list[Sign] = []

        for t in range(num_steps):
            # Get the data for days 1...start_day + t - 1
            data_to_t = self.get_data_up_to_t(data, start_day+t)

            # Have experts make predictions based on this data, and decide using their opinions
            predictions = self.get_predictions(data_to_t)
            decision = self.get_decision(predictions)
            assert decision in (1, -1)
            decisions.append(decision)

            # Reveal the ground truth
            outcome = self.get_outcome(data, start_day+t)
            expert_mistakes[predictions != outcome] += 1
            if outcome != decision:
                total_mistakes += 1

            self.update_weights(predictions, outcome)
            # Rescale weights every 5 steps to avoid underflow
            if t % 5 == 0:
                self.scale_weights()

        reward = self.get_rewards(data, start_day, decisions)
        mistakes = self.get_mistakes(data, start_day, decisions)
        best_expert_mistakes = np.min(expert_mistakes)
        mistake_ratio = mistakes / best_expert_mistakes if best_expert_mistakes else np.inf

        print(f"Number of experts: {len(self.experts)}")
        print(f"Number of trading days: {num_steps}")
        print(f"Number of mistakes: {mistakes}")
        print(f"Mistake rate: {mistakes / len(decisions):.1%}")
        print(f"Number of mistakes made by best expert: {best_expert_mistakes}")
        print(f"Ratio of alg mistakes to best expert: {mistake_ratio:.2f}")
        print(f"Profit/Loss: {reward:.2f}")

        return (mistakes, best_expert_mistakes, mistake_ratio)