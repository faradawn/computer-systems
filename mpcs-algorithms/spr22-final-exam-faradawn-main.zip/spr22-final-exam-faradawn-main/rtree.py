from __future__ import annotations

from functools import cached_property

from typing import Iterable

from shapely.geometry.base import BaseGeometry

# Hi,
# The insert, splite, and update_ancestor are believed to work
# However, the search recursion is not fully functional 
# Thanks you so much for the time!
# Wish you a great day!

def print_geo(geos):
    arr = [str(geo) for geo in geos]
    print(arr)

def sort_points(points, point):
    points.sort(key = lambda p: point.distance(p))
    print_geo(points)

class Node:
    def __init__(self, min_degree: int, parent: InternalNode | None = None):
        self.min_degree = min_degree
        self.parent = parent
        self.bbox = BaseGeometry()

    def update_ancestors(self):
        """Update the bounding boxes of each ancestor to reflect changes to self.bbox"""
        p = self.parent
        i = 1
        while p is not None:
            for child in p.children:
                print("children", i, child.__repr__())
                p.bbox = p.bbox.union(child.bbox).envelope
                i += 1
            if p.is_full and p.parent is not None:
                p.split(None)
            p = p.parent

    @property
    def max_degree(self) -> int:
        return 2 * self.min_degree

    @property
    def is_leaf(self) -> bool:
        raise NotImplementedError

    @property
    def is_full(self) -> bool:
        raise NotImplementedError

    def split(self, payload):
        raise NotImplementedError


def farthest(geometries: list[BaseGeometry]) -> tuple(BaseGeometry):
    l = len(geometries)
    max_dist = 0
    max_points = ()
    for i in range(l):
        for j in range(i, l):
            if geometries[i].distance(geometries[j]) > max_dist:
                max_dist = geometries[i].distance(geometries[j])
                max_points = (geometries[i], geometries[j])
    return max_points



class LeafNode(Node):
    """A leaf node stores some geometries."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.geometries: list[BaseGeometry] = []

    @cached_property
    def is_leaf(self) -> bool:
        return True

    @property
    def is_full(self) -> bool:
        return len(self.geometries) >= self.max_degree

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({', '.join(str(geom) for geom in self.geometries)})"

    def add(self, payload: BaseGeometry):
        """Adds the given geometry to this leaf node."""
        if self.is_full:
            self.split(payload)
        else:
            self.geometries.append(payload)
        self.bbox = self.bbox.union(payload).envelope
        self.update_ancestors() # leaf

    def split(self, payload: BaseGeometry):
        """Splits this leaf node into two new leaf nodes."""
        self.geometries.append(payload)
        far_points = farthest(self.geometries)
        node_1 = LeafNode(min_degree=self.min_degree, parent=self.parent)
        node_2 = LeafNode(min_degree=self.min_degree, parent=self.parent)
        self.parent.children.append(node_1)
        self.parent.children.append(node_2)
        node_1.bbox = node_1.bbox.union(far_points[0])
        node_2.bbox = node_2.bbox.union(far_points[1])

        # method 2: sort the points closest to farpoint[0]
        # sort_points(self.geometries, far_points[0])  
        # for i in range(self.min_degree):
        #     node_1.geometries.append(self.geometries[i])
        #     node_2.geometries.append(self.geometries[i+1+self.min_degree])

        # # now decide where to put the middle point
        # if self.geometries[self.min_degree].distance(far_points[0]) < self.geometries[self.min_degree].distance(far_points[1]):
        #     node_1.geometries.append(self.geometries[self.min_degree])
        # else:
        #     node_2.geometries.append(self.geometries[self.min_degree])

        for geo in self.geometries:
            if geo.distance(far_points[0]) < geo.distance(far_points[1]) or len(node_2.geometries) >= self.min_degree+1:
                node_1.geometries.append(geo)
                node_1.bbox = node_1.bbox.union(geo).envelope
            elif geo.distance(far_points[1]) < geo.distance(far_points[0]) or len(node_1.geometries) >= self.min_degree+1:
                node_2.geometries.append(geo)
                node_2.bbox = node_2.bbox.union(geo).envelope

        self.parent.remove(self)


        # TODO
        # Find the two geometries which are farthest apart (including the payload).
        # Create two new leaf nodes, seeded with these geometries.
        # Split the remaining geometries between these two nodes.
        # Assign each to the node requiring the minimum enlargement to accommodate it.
        # Ensure that both new nodes have at least self.min_degree geometries.
        # Remove old node from parent and add new nodes.


class InternalNode(Node):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.children: list[Node] = []

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(bbox={self.bbox}, children={len(self.children)})"

    @cached_property
    def is_leaf(self) -> bool:
        return False

    @property
    def is_full(self) -> bool:
        return len(self.children) >= self.max_degree

    def add(self, payload: Node):
        """Adds the given node to this internal node."""
        if self.is_full:
            self.split(payload)
        else:
            self.children.append(payload)
        self.bbox = self.bbox.union(payload.bbox).envelope
        self.update_ancestors()

    def remove(self, child: Node):
        self.children.remove(child)

    def split(self, payload: Node): # internal node
        """Splits this internal node into two new internal nodes."""
        far_points = farthest([child.bbox for child in self.children])
        node_1 = InternalNode(min_degree=self.min_degree, parent=self.parent)
        node_2 = InternalNode(min_degree=self.min_degree, parent=self.parent)
        self.parent.children.append(node_1)
        self.parent.children.append(node_2)
        node_1.bbox = node_1.bbox.union(far_points[0])
        node_2.bbox = node_2.bbox.union(far_points[1])

        for geo in self.children:
            if geo.bbox.distance(far_points[0]) < geo.bbox.distance(far_points[1]) or len(node_2.children) >= self.min_degree+1:
                node_1.children.append(geo)
                node_1.bbox = node_1.bbox.union(geo.bbox).envelope
            elif geo.bbox.distance(far_points[1]) < geo.bbox.distance(far_points[0]) or len(node_1.children) >= self.min_degree+1:
                node_2.children.append(geo)
                node_2.bbox = node_2.bbox.union(geo.bbox).envelope

        self.parent.remove(self)
        


class RTree:
    def __init__(self, min_degree: int):
        self.min_degree = min_degree
        self.root: Node = LeafNode(min_degree=min_degree)

    def insert(self, payload: BaseGeometry):
        """Inserts the given geometry into the tree."""

        if self.root.is_leaf: # root is leaf node
            if not self.root.is_full:
                self.root.geometries.append(payload)
                self.root.bbox = self.root.bbox.union(payload).envelope
            else:
                old_root = self.root
                self.root = InternalNode(min_degree=self.min_degree)
                old_root.parent = self.root
                self.root.add(old_root) # old_root will be removed from root's children during split
                old_root.split(payload)

        else: # root is internal node
            cur = self.root
            while cur and not cur.is_leaf:
                # (new_area - current_area) / current_area
                # find the node with minimum proportion of area increase
                cur_area = cur.children[0].bbox.area
                new_area = cur.children[0].bbox.union(payload).envelope.area
                if cur_area == 0:
                    cur_area = 0.00000001
                min_area_incr = (new_area - cur_area) / cur_area
                min_child = cur.children[0]
                

                for child in cur.children:
                    cur_area = child.bbox.area
                    new_area = child.bbox.union(payload).envelope.area
                    if cur_area == 0:
                        cur_area = 0.00000001
                    if (new_area - cur_area) / cur_area < min_area_incr:
                        min_area_incr = (new_area - cur_area) / cur_area
                        min_child = child
                cur = min_child
            min_child.add(payload)

            if self.root.is_full:
                old_root = self.root
                self.root = InternalNode(min_degree=self.min_degree)
                old_root.parent = self.root
                self.root.add(old_root)
                old_root.split(None)
            
            



    def search(self, query: BaseGeometry, start_node: Node | None = None) -> Iterable[BaseGeometry]:
        """Searches the tree for geometries contained by the query geometry."""
        if start_node is None:
            start_node = self.root
        
        if query.intersects(start_node.bbox):
            if start_node.is_leaf:
                for geo in start_node.geometries:
                    if query.intersects(geo):
                        yield geo
            else:
                for child in start_node.children:
                    if query.intersects(child.bbox):
                        self.search(query, child)
        

    def display(self, level=0, node: Node | None = None):
        """Prints the tree structure to the command line."""
        if node is None:
            node = self.root

        print(f"{'|   ' * level}|-- {node}")
        if not node.is_leaf:
            for child in node.children:
                self.display(level=level + 1, node=child)
            


if __name__ == "__main__":
    import random

    from shapely.geometry import Point, Polygon

    random.seed(6)

    rtree = RTree(min_degree=2)
    num_points = 2
    # for _ in range(num_points):
    #     x = round(random.random(), 2)
    #     y = round(random.random(), 2)
    #     pt = Point(x, y)
    #     rtree.insert(pt)
    #     rtree.display()

    # working example
    # points=[Point(10,15), Point(15,20), Point(25,10), Point(30,15), Point(21,15), Point(36, 20), Point(37,20), Point(38,20)]
    # for pt in points:
    #     rtree.insert(pt)
    # rtree.display()
    
    # polygon = Polygon([(1, 1), (1, 0.5), (0.5, 0.5), (0.5, 1)])
    # results = list(rtree.search(polygon))
    # assert all(polygon.contains(result) for result in results)
    # import pprint
    # pprint.pprint([str(res) for res in results])
