from __future__ import annotations

from rb_tree import Node, RedBlackTree


class ValidNumberTree(RedBlackTree):
    def __init__(self):
        super().__init__(node_cls=Node, tnull_val=0)

    def display_in_order(self):
        self.in_order(display=True)

    def add_range(self, lo: int, hi: int):
        """Marks the given range as valid.

        Parameters
        ----------
        lo : int
            Start of range.
        hi : int
            End of range.
        """
        self.insert((lo,0)) # 0 means left endpoint
        self.insert((hi,1)) # 1 means right endpoint
        self.update_height() # update the number of left and right endpoints to the left of this node 

    def is_valid(self, x: int) -> bool:
        """Checks if x is valid.

        Parameters
        ----------
        x : int
            Search value.

        Returns
        -------
        valid : bool
            Boolean indicating whether or not x is valid.
        """
        num = self.query(x) # number of intervals containing x
        if num == 0:
            return False
        else:
            return True

