# Satellite Imaging

You have been hired by a satellite imaging company as part of the New Space boom. 
The company has a fleet of several observation satellites. 
They have signed deals with a number of commercial and government customers, 
each of which has provided them with a list of targets to observe.
The company would like you to decide how to make optimal use of their constellation, 
subject to the following constraints:
- Each satellite has 3 sensors which operate on 3 different frequencies and can be pointed independently. 
- Each sensor must be pointed at one of the targets, but will cover additional targets within 5km of its target.
- The angle between a satellite and each of its targets should be no more than 45 degrees from vertical 
(from the satellite's perspective).
- Active sensors emit light in order to illuminate their target during imaging. 
Due to government regulations on electromagnetic radiation, 
no target should be covered twice by sensors of the same frequency. 

You are given the positions of the satellites and the targets in LLA coordinates (latitude, longitude, altitude).

Your assignment is to set this up as an optimization problem and solve it using an open-source optimization package, 
such as Google's [OR-Tools](https://developers.google.com/optimization).

An implicit constraint in this problem is that some or all of the variables must be boolean. 
This is known as [integer programming](https://en.wikipedia.org/wiki/Integer_programming), 
and makes the problem NP-complete, unlike LPs with continuous variables which have algorithms with polynomial guarantees.
Regardless, freely available solvers can still solve many integer programs to optimality in a reasonable amount of time.

Reference: [OR-Tools guide to integer programs](https://developers.google.com/optimization/mip).

## Dependencies
`geopy` provides useful functionality for geolocation, which includes calculating angles and distances on spherical surfaces with latitude and longitude. The LLA coordinates used in this exercise are all provided as `geopy.point.Point` objects, which you can manipulate using other functions in the library. You can install `geopy` with:
```
pip install geopy
```

Additionally, if you want the GitHub autograder to run the automated tests, you can add the optimization package(s)
you are using to `requirements.txt`.