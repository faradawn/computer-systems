from __future__ import annotations

from geopy import Point
from geopy.distance import geodesic
import numpy as np

def generate_point(center: Point, radius_km: float, rng: np.random.Generator) -> Point:
    random_distance = rng.random() * radius_km
    random_bearing = rng.random() * 360
    return geodesic(kilometers=random_distance).destination(center, random_bearing)

def generate_instance(
    num_sats: int,
    num_targets: int, 
    center_latitude: float = 0, 
    center_longitude: float = 0, 
    radius_km: float = 60, 
    sat_altitude_km: float = 1000.0, 
    target_altitude_km: float = 0.0,
    random_seed: int | None = None,
) -> tuple[list[Point], list[Point]]:
    """Generates a random instance of the satellite imaging problem."""
    rng = np.random.default_rng(random_seed)
    center = Point(center_latitude, center_longitude, sat_altitude_km)
    satellites = [generate_point(center, radius_km, rng) for _ in range(num_sats)]
    center.altitude = target_altitude_km
    targets = [generate_point(center, radius_km, rng) for _ in range(num_targets)]
    return satellites, targets
