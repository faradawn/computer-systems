import pytest

from geopy import Point
from geopy.distance import Distance, geodesic
from main import Sensor, optimize_imaging_targets


@pytest.mark.parametrize(
    "satellites,targets,coverage",
    [
        ([Point(0, 0, 1000)], [Point(0, 0, 1)], 1),
        ([Point(0, 0, 10000)], [Point(0, 0, 1), Point(0.01, 0, 0)], 2),
        ([Point(90, 0, 10000)], [Point(90, 0, 0), Point(90, 180, 0)], 2),
        ([Point(90, 0, 10000)], [Point(-90, 0, 0), Point(90, 180, 0)], 1),
        ([Point(90, 0, 10000)], [Point(-90, 0, 0), Point(-90, 180, 0)], 0),
        ([Point(30, 40, 1)], [Point(31, 40, 0)], 0),
        (
            [Point(30, 40, 10000)],
            [Point(31, 40, 0), Point(30, 43, 0), Point(28, 38, 0)],
            3,
        ),
        (
            [Point(0, 90, 10000), Point(0, -90, 10000)],
            [Point(14, 20, 2), Point(-14, -140, 3)],
            1,
        ),
    ],
)
def test_optimize(satellites, targets, coverage):
    result = optimize_imaging_targets(satellites, targets)

    sat_sen_used = set()
    targets_covered_sensor = set()
    targets_covered_total = set()
    for sat, sen, tar in result:
        # Check for unique sensor assignments
        assert (sat, sen) not in sat_sen_used
        sat_sen_used.add((sat, sen))

        # Check for angle constraint (future commit)

        # Check for unique target coverage
        for i, nearby_target in enumerate(targets):
            zero_alt_tar = Point(targets[tar].latitude, targets[tar].longitude, 0)
            zero_alt_nearby = Point(nearby_target.latitude, nearby_target.longitude, 0)
            if geodesic(zero_alt_tar, zero_alt_nearby) <= Distance(kilometers=5):
                assert (i, sen) not in targets_covered_sensor
                targets_covered_sensor.add((i, sen))
                targets_covered_total.add(i)

    assert len(targets_covered_total) == coverage

