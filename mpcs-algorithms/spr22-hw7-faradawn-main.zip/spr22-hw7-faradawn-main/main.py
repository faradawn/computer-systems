from __future__ import annotations

from enum import Enum, auto
from geopy.point import Point
import numpy as np
from ortools.linear_solver import pywraplp
import math

class Sensor(Enum):
    A = auto()
    B = auto()
    C = auto()

def to_ecef(p): # convert to ECEF coordinate
    lat = p[0]
    lon = p[1]
    alt = p[2]
    rad_lat = lat * (math.pi / 180.0)
    rad_lon = lon * (math.pi / 180.0)

    a = 6378137.0
    finv = 298.257223563
    f = 1 / finv
    e2 = 1 - (1 - f) * (1 - f)
    v = a / math.sqrt(1 - e2 * math.sin(rad_lat) * math.sin(rad_lat))

    x = (v + alt) * math.cos(rad_lat) * math.cos(rad_lon)
    y = (v + alt) * math.cos(rad_lat) * math.sin(rad_lon)
    z = (v * (1 - e2) + alt) * math.sin(rad_lat)

    return x, y, z

def satellite_angle(satellite, target): # from satellite's point of view
    x,y,z = to_ecef(satellite)
    xx,yy,zz = to_ecef(target)
    if not np.any(np.cross((x,y,z), (xx,yy,zz))): # if cross product is zero means parallel
        return 0

    dx = xx - x
    dy = yy - y
    dz = zz - z

    cos_ele = (-x*dx + -y*dy + -z*dz) / math.sqrt((x**2+y**2+z**2)*(dx**2+dy**2+dz**2))
    angle_ele = abs(math.acos(cos_ele) * 180/math.pi)
    if angle_ele > 90:
        return angle_ele - 90
    else:
        return angle_ele

def target_angle(satellite, target): # from target's point of view
    x,y,z = to_ecef(satellite)
    xx,yy,zz = to_ecef(target)
    if not np.any(np.cross((x,y,z), (xx,yy,zz))): # the cross product is zero
        return 0

    cos_ele = (x*xx + y*yy + z*zz) / math.sqrt((x**2+y**2+z**2)*(xx**2+yy**2+zz**2))
    angle_ele = math.acos(cos_ele) * 180/math.pi
    return abs(angle_ele)
   

def optimize_imaging_targets(satellites: list[Point], targets: list[Point],) -> list[tuple[int, Sensor, int]]:
    """Optimize imaging targets, returning a list of (sat, sensor, target) assignments."""
    # Let variable t_i,j,k be whether satellite i's sensor j points to target k
    #   t_i,j,k is an indicator variable that takes on values of 1 or 0
    #   We want to maximize the points coverded.

    # First, pre-process the points around each t_i,j,k to filter
    #   which points are within 5km of t_i,j,k. 
    #   We also consider the 45 angle constraint.

    # Second, set the objective function be the sum of the 
    #   points within each t_i,j,k's 5km radius.
    #   We only count the points whose center t_i,j,k is 1

    solver = pywraplp.Solver.CreateSolver('SCIP')

    t = [] # build a 3D array for t_i,j,k variables
    cluster = [] # cluster of points for each t_i,j,k within 5km
    count = [] # counts the number of points in each cluster
    for i in range(len(satellites)):
        t.append([])
        cluster.append([])
        count.append([])
        for j in range(len(3)):
            t[i].append([])
            cluster.append([])
            count.append([])
            for k in range(len(targets)):
                t[i][j].append(0)
                cluster.append(0)
                count.append(0)
    
    # initialize the variables 
    for i in range(len(satellites)):
        for j in range(len(3)):
            for k in range(len(targets)):
                t[i][j][k] = solver.IntVar(0, 1, 't_{}_{}_{}'.format(i,j,k))
                # decide which points can be included in which cluster
                for p in targets:
                    if Distance(p, targets[k]) <= 5 and satellite_angle(satellites[i], p) <= 45:
                        cluster[i][j][k].append(p) # the constraint that no two points can be covered by two same sensor is added below
                        count[i][j][k] += 1

    # add constaints all satellite's sensor A's cluster must be pairwise disjoint
    # in other words, a point cannot be pointed by two sensor A's
    for j in range(len(3)):
        sum_indicators = 0
        for i in range(len(satellites)):    
            for k in range(len(targets)):
                 sum_indicators += t[i][j][k]
        solver.Add(sum_indicators <= 1)
    
    # objective is to maximze the total number of points covered
    # de-duplicate is believed to be achieved by the previous constraint

    solver.Maximize(sum(count))

    # build the result from indicators
    res = []
    for i in range(len(satellites)):
        for j in range(len(3)):
            for k in range(len(targets)):
                if t[i][j][k].solution_value() == 1:
                    res.append((satellites[i], Sensor[j], targets[k]))
    
    return res

    # sorry that the code might not be functional
    # it must be hard for you to read!
    # thank you for the time!
    # if there is anything I could do, please let me know! 



    
if __name__ == "__main__":
    tests = [
        ([Point(0, 0, 1000)], [Point(0, 0, 1)], 1),
        ([Point(0, 0, 10000)], [Point(0, 0, 1), Point(0.01, 0, 0)], 2),
        ([Point(90, 0, 10000)], [Point(90, 0, 0), Point(90, 180, 0)], 2),
        ([Point(90, 0, 10000)], [Point(-90, 0, 0), Point(90, 180, 0)], 1),
        ([Point(90, 0, 10000)], [Point(-90, 0, 0), Point(-90, 180, 0)], 0),
        ([Point(30, 40, 1)], [Point(31, 40, 0)], 0),
        (
            [Point(30, 40, 10000)],
            [Point(31, 40, 0), Point(30, 43, 0), Point(28, 38, 0)],
            3,
        ),
        (
            [Point(0, 90, 10000), Point(0, -90, 10000)],
            [Point(14, 20, 2), Point(-14, -140, 3)],
            1,
        ),
    ]
    optimize_imaging_targets(tests[3][0], tests[3][1])
    
