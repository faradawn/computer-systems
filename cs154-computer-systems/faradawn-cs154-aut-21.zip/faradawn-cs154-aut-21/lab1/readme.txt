Hi, this is Faradawn!

------------------------------------------------------------------------
r6 | faradawn | 2021-09-28 11:20:53 -0500 (Tue, 28 Sep 2021) | 1 line

change and delete
------------------------------------------------------------------------
r2 | ruidanli | 2021-09-27 13:30:32 -0500 (Mon, 27 Sep 2021) | 1 line

creating lab1
------------------------------------------------------------------------

Index: ex3/names.txt
===================================================================
--- ex3/names.txt	(nonexistent)
+++ ex3/names.txt	(working copy)
@@ -0,0 +1 @@
+Faradawn Yang

svn diff -r 7:8
Index: ex3/names.txt
===================================================================
--- ex3/names.txt	(nonexistent)
+++ ex3/names.txt	(revision 8)
@@ -0,0 +1 @@
+Faradawn Yang
Index: readme.txt
===================================================================
--- readme.txt	(revision 7)
+++ readme.txt	(revision 8)
@@ -9,3 +9,10 @@
 creating lab1
 ------------------------------------------------------------------------
 
+Index: ex3/names.txt
+===================================================================
+--- ex3/names.txt	(nonexistent)
++++ ex3/names.txt	(working copy)
+@@ -0,0 +1 @@
++Faradawn Yang
+



Index: names.txt
===================================================================
--- names.txt	(revision 9)
+++ names.txt	(working copy)
@@ -1 +1 @@
-Hey,Faradawn Yang
+Faradawn Yang



