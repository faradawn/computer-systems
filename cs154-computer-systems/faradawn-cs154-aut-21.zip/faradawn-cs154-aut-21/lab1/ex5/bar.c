#include "bar.h"
#include <stdio.h>

int returnOne(void) {
  puts("hello");
  return 1;
}
