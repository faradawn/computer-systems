#include "bar.h"

int returnOne(void) {
  return 1;
}
