
int absVal(int);
int test_absVal(int);
int addOK(int, int);
int test_addOK(int, int);
int allEvenBits();
int test_allEvenBits();
//#include "allOddBits.c"
//#include "anyEvenBit.c"
//#include "anyOddBit.c"
int bang(int);
int test_bang(int);
//#include "bitAnd.c"
int bitCount(int);
int test_bitCount(int);
//#include "bitMask.c"
int bitNor(int, int);
int test_bitNor(int, int);
//#include "bitOr.c"
//#include "bitParity.c"
//#include "bitXor.c"
int byteSwap(int, int, int);
int test_byteSwap(int, int, int);
int conditional(int, int, int);
int test_conditional(int, int, int);
//#include "copyLSB.c"
//#include "divpwr2.c"
//#include "evenBits.c"
int ezThreeFourths(int);
int test_ezThreeFourths(int);
int fitsBits(int, int);
int test_fitsBits(int, int);
//#include "fitsShort.c"
//#include "float_abs.c"
//#include "float_f2i.c"
//#include "float_half.c"
//#include "float_i2f.c"
//#include "float_neg.c"
//#include "float_twice.c"
int getByte(int, int);
int test_getByte(int, int);
int greatestBitPos(int);
int test_greatestBitPos(int);
//#include "howManyBits.c"
//#include "ilog2.c"
int implication(int, int);
int test_implication(int, int);
int isAsciiDigit(int);
int test_isAsciiDigit(int);
int isEqual(int, int);
int test_isEqual(int, int);
//#include "isGreater.c"
int isLess(int, int);
int test_isLess(int, int);
//#include "isLessOrEqual.c"
//#include "isNegative.c"
int isNonNegative(int);
int test_isNonNegative(int);
//#include "isNonZero.c"
//#include "isNotEqual.c"
//#include "isPositive.c"
int isPower2(int);
int test_isPower2(int);
//#include "isTmax.c"
int isTmin(int);
int test_isTmin(int);
//#include "isZero.c"
//#include "leastBitPos.c"
//#include "leftBitCount.c"
//#include "logicalNeg.c"
//#include "logicalShift.c"
int minusOne();
int test_minusOne();
//#include "multFiveEighths.c"
//#include "negate.c"
//#include "oddBits.c"
//#include "rempwr2.c"
//#include "replaceByte.c"
//#include "reverseBytes.c"
int rotateLeft(int, int);
int test_rotateLeft(int, int);
//#include "rotateRight.c"
//#include "satAdd.c"
int satMul2(int);
int test_satMul2(int);
//#include "satMul3.c"
//#include "sign.c"
//#include "sm2tc.c"
//#include "subOK.c"
//#include "tc2sm.c"
//#include "thirdBits.c"
//#include "tmax.c"
//#include "tmin.c"
//#include "trueFiveEighths.c"
//#include "trueThreeFourths.c"
//#include "upperBits.c"
